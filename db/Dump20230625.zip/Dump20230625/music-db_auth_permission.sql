-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: music-db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add track',9,'add_track'),(26,'Can change track',9,'change_track'),(27,'Can delete track',9,'delete_track'),(28,'Can view track',9,'view_track'),(29,'Can add album',10,'add_album'),(30,'Can change album',10,'change_album'),(31,'Can delete album',10,'delete_album'),(32,'Can view album',10,'view_album'),(33,'Can add artist',11,'add_artist'),(34,'Can change artist',11,'change_artist'),(35,'Can delete artist',11,'delete_artist'),(36,'Can view artist',11,'view_artist'),(37,'Can add nation',12,'add_nation'),(38,'Can change nation',12,'change_nation'),(39,'Can delete nation',12,'delete_nation'),(40,'Can view nation',12,'view_nation'),(41,'Can add track genre',13,'add_trackgenre'),(42,'Can change track genre',13,'change_trackgenre'),(43,'Can delete track genre',13,'delete_trackgenre'),(44,'Can view track genre',13,'view_trackgenre'),(45,'Can add genre',14,'add_genre'),(46,'Can change genre',14,'change_genre'),(47,'Can delete genre',14,'delete_genre'),(48,'Can view genre',14,'view_genre'),(49,'Can add saved',15,'add_saved'),(50,'Can change saved',15,'change_saved'),(51,'Can delete saved',15,'delete_saved'),(52,'Can view saved',15,'view_saved'),(53,'Can add track artist',16,'add_trackartist'),(54,'Can change track artist',16,'change_trackartist'),(55,'Can delete track artist',16,'delete_trackartist'),(56,'Can view track artist',16,'view_trackartist'),(57,'Can add playlist user',17,'add_playlistuser'),(58,'Can change playlist user',17,'change_playlistuser'),(59,'Can delete playlist user',17,'delete_playlistuser'),(60,'Can view playlist user',17,'view_playlistuser'),(61,'Can add playlist system',18,'add_playlistsystem'),(62,'Can change playlist system',18,'change_playlistsystem'),(63,'Can delete playlist system',18,'delete_playlistsystem'),(64,'Can view playlist system',18,'view_playlistsystem'),(65,'Can add playlist',19,'add_playlist'),(66,'Can change playlist',19,'change_playlist'),(67,'Can delete playlist',19,'delete_playlist'),(68,'Can view playlist',19,'view_playlist'),(69,'Can add follower',20,'add_follower'),(70,'Can change follower',20,'change_follower'),(71,'Can delete follower',20,'delete_follower'),(72,'Can view follower',20,'view_follower'),(73,'Can add favorite',21,'add_favorite'),(74,'Can change favorite',21,'change_favorite'),(75,'Can delete favorite',21,'delete_favorite'),(76,'Can view favorite',21,'view_favorite');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-25 21:15:36
